# Fonts for Offline Build

This directory should contain locally bundled font files for the Android offline build.

## Required Fonts

1. **Roboto** (weights: 300, 400, 500)
   - Download from: https://fonts.google.com/specimen/Roboto
   - Place files in: `src/assets/fonts/roboto/`
   - Files needed: Roboto-Light.woff2, Roboto-Regular.woff2, Roboto-Medium.woff2

2. **Material Icons**
   - Download from: https://fonts.google.com/icons
   - Place file in: `src/assets/fonts/material-icons/`
   - File needed: MaterialIcons-Regular.woff2

## Directory Structure

```
src/assets/fonts/
├── roboto/
│   ├── Roboto-Light.woff2
│   ├── Roboto-Regular.woff2
│   └── Roboto-Medium.woff2
└── material-icons/
    └── MaterialIcons-Regular.woff2
```

## Notes

- Use woff2 format for best compression
- Font files will be bundled into the build
- The offline build will use these local fonts instead of loading from CDN
- Other fonts (DM Sans, Inter, Font Awesome) will fall back to Roboto or system fonts

